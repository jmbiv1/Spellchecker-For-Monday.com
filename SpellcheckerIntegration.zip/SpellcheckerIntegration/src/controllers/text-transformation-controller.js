const mondayService = require('../services/monday-service');
const API_TOKEN = process.env.API_TOKEN;

async function transformToMondayColumn(req, res) {
  const { payload } = req.body;
  const { inboundFieldValues } = payload;
  const { boardId, itemId, sourceColumnId, targetColumnId, transformationType } = inboundFieldValues;

  const token = API_TOKEN;
  const texty = await mondayService.getColumnValue(token, itemId, sourceColumnId);
  if (!texty) {
    return res.status(200).send({});
  }

  const str2 = JSON.parse(texty);
  
  var Typo = require("typo-js");
  var dictionary = new Typo( "en_US" );
  
  var splitValue = str2.split(" ");
    
  var i;
  var suggestions = new Array();
  var newPhrase = "";
  
	for (i = 0; i < splitValue.length; i++) {
		//if word is spelled incorrectly
		if (dictionary.suggest(splitValue[i]).length != 0) { 
			suggestions[i] = dictionary.suggest(splitValue[i]);
			
			//if beginning of incorrect phrase
			if (i == 0 && splitValue.length != 1) {
			newPhrase = suggestions[i][0] + " ";
			}
			
			//if middle of incorrect phrase
			else if (i < splitValue.length - 1) {
			newPhrase = newPhrase + suggestions[i][0] + " ";
			}
			
			//if end of incorrect phrase
			else {
			newPhrase = newPhrase + suggestions[i][0];
			}
		} //if word is spelled correctly
		else if (i < splitValue.length - 1) {
			newPhrase = newPhrase + splitValue[i] + " ";
		}
		  //if end of text entry
		else {
			newPhrase = newPhrase + splitValue[i];
		}
	} 
	jsn2 = JSON.stringify(newPhrase);

  await mondayService.changeColumnValue(token, boardId, itemId, targetColumnId, jsn2);

  return res.status(200).send({});
}

async function subscribe(req, res) {
  return res.status(200).send({
    webhookId: req.body.payload.subscriptionId,
    result: 'Success'
  });
}

async function unsubscribe(req, res) {
  return res.status(200).send({result: 'Success'});
}

module.exports = {
  transformToMondayColumn,
  subscribe,
  unsubscribe
};
